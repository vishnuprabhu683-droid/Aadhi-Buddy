# Aadhi AI — Tamil + English Kids Learning & Feelings App

A free, offline-first prototype for children aged 3–5. Includes emotion check-ins, calming breathing prompt, kindness scenarios, bilingual preschool activities, stories, mini-games, browser/device speech, local star progress, a PWA shell and an Android WebView project.

## What works in this prototype
- Emotion check-in for happy, sad, angry, worried, calm and excited, with supportive age-appropriate prompts.
- Simple breathing animation and reminder to speak with a trusted grown-up.
- Tamil + English learning activities for letters, numbers, colours, animals, shapes and body parts.
- Bilingual kindness scenario, short story, mini-game and guided Aadhi Buddy responses.
- Offline PWA caching and local-only star/language preferences.
- Android WebView wrapper loading the same local app assets.

## Important limits — read before giving to children
- This is a working prototype, not a clinically validated emotional-health product or a finished public release.
- “Aadhi Buddy” is a curated, rule-based/offline demo, not a live generative AI model. No AI API/backend is connected. Do not add an API key to client-side code.
- Voice uses speech synthesis provided by the device/browser. Tamil voice availability varies by device and installed language packs.
- Parent gate is a simple demo arithmetic check, not secure parental authentication or verifiable parental consent.
- No account, cloud sync, microphone recording, camera, location tracking, advertising, payments or analytics are implemented.
- Have a parent/teacher supervise use. The app does not diagnose emotions or replace a caregiver or professional.
- Before public distribution, complete child-safety/privacy/legal review, consent flow, accessibility and device testing, content review by Tamil educators, and secure backend design if online AI is added.

## Open the web app
Open `web/index.html` in a browser for a quick local preview. For PWA installation/offline caching, host the `web` folder over HTTPS or localhost and choose **Add to Home screen** in a supported browser.

## Build the Android APK
The current workspace does not contain the Android SDK/Gradle build environment, so an APK has not been compiled here. The Android source project and GitHub Actions workflow are included.

1. Create a new GitHub repository and upload the contents of this ZIP.
2. Open **Actions** → **Build Aadhi AI APK** → **Run workflow**.
3. When the workflow succeeds, open its run page and download the `aadhi-ai-debug-apk` artifact.
4. Extract the artifact ZIP; install `app-debug.apk` on the Android phone. Android may ask you to allow installation from that source.

For local builds, use Android Studio with Android SDK 35 and Gradle 8.9; open the `android` folder and run `assembleDebug`.

## Free status
The included app code has no paid SDK, subscription, ad network or API dependency. Hosting, if you choose to publish the web app online, may have separate provider limits/charges. The Android debug APK can be built free using GitHub Actions' available free quota.
